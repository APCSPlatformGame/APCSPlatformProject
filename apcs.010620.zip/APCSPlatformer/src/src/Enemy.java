package src;

import java.awt.Graphics;
import java.awt.Image;


public class Enemy extends Entity implements Paint{

	public Enemy(int size, Image gif, int x, int y) {
		super(size, gif, x, y);
	}

	@Override
	public void paint(Graphics g) {
		// TODO Auto-generated method stub
		
	}

}
