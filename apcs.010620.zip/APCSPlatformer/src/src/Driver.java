package src;

public class Driver {
	public static void main(String[] args) {
		World w = new World(null);
	}
}
