# APCSPlatformer
A platformer game made for APCS
# Game Synopsis
A simple 2D platformer where the player must collect scrap to advance onto the next stage, with obstacles to block their path.
Set in a post-apocolyptic future, ancient robots pose the biggest threat to the player. 
# Class Overview
World - Contains Jpanel and handles BG
Entity - Anything not designed to hurt the player or is the player is an entitiy, including npc dialouge and also walls.
Enemy (Extends Entity) - Hurts the player.
Player (Extends Entity) - Controlled by the player.
# Project Goals
Todo:
World
Entity
Player
Enemy
