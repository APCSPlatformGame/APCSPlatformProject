package src;

//Controls:
// A Left
// D Right
// S Crouch
// W/Space Jump
// Q strike (no animation)

public class Driver {
	public static void main(String args[]) {
		World w = new World();
	}
	
}
