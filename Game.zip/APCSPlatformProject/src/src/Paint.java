package src;

import java.awt.Graphics;

public interface Paint {
	public void paint(Graphics g);
}
